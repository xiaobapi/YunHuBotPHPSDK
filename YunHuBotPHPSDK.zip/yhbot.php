<?php
include('need.php');

$num_all_in_data=file_get_contents("bot/num/all_in.txt");
if(!$num_all_in_data){
$num_all_in_data='0';
}
file_put_contents("bot/num/all_in.txt",($num_all_in_data+1));

$date=date("Y-m-d");
$num_in_data=file_get_contents("bot/num/".$date."_in.txt");
if(!$num_in_data){
$num_in_data='0';
}
file_put_contents("bot/num/".$date."_in.txt",($num_in_data+1));

$server_data=file_get_contents("php://input");
//file_put_contents("bot/bot_data.txt",send($server_data,"test"));
$data=file_get_contents("php://input");


$log_data=file_get_contents("bot/bot.log");
file_put_contents("bot/bot.log",$log_data."\n".$server_data);

/*
{"version":"1.0","header":{"eventId":"607f48af1d904eceb645acabf1a5be4c","eventType":"message.receive.normal","eventTime":1673166114195},"event":{"sender":{"senderId":"3654755","senderType":"user","senderUserLevel":"owner"},"chat":{"chatId":"823279556","chatType":"group"},"message":{"msgId":"ae4062889e5247789f25785499b28322","parentId":"","sendTime":1673166114117,"chatId":"823279556","chatType":"group","contentType":"text","content":{"text":"5"},"instructionId":0,"instructionName":""}}}

"header":{"eventId":"c75a5a610b2d4fb988a7f799528e2da3","eventType":"message.receive.normal","eventTime":1673165576576},

"event":{"sender":{"senderId":"3654755","senderType":"user","senderUserLevel":"member"},"chat":{"chatId":"25203250","chatType":"bot"},"message":{"msgId":"397a050af0674613a681cc68abdfb4a9","parentId":"","sendTime":1673165576569,"chatId":"25203250","chatType":"bot","contentType":"text","content":{"text":"6"},"instructionId":0,"instructionName":""}}

{"version":"1.0","header":{"eventId":"96aa604d641c4903a179fb93585c16d8","eventType":"message.receive.normal","eventTime":1673166879923},"event":{"sender":{"senderId":"3654755","senderType":"user","senderUserLevel":"owner"},"chat":{"chatId":"823279556","chatType":"group"},"message":{"msgId":"5151c2f271664d20a73b2410d31163c6","parentId":"","sendTime":1673166879877,"chatId":"823279556","chatType":"group","contentType":"image","content":{"imageUrl":"https://chat-storage1.jwznb.com/ef621a1881f885d8144b3dad0bc9eeb4.jpg?sign=2b6dfa8f992c35cf11d93cb1fed95de1\u0026t=63ba8e2f","imageName":"ef621a1881f885d8144b3dad0bc9eeb4.jpg"},"instructionId":0,"instructionName":""}}}
*/

/*
群信息
{
    "version":"1.0",
    "header":{
        "eventId":"059fce84a7b641fba814c031e714160e",
        "eventType":"message.receive.normal",
        "eventTime":1673194941833
    },
    "event":{
        "sender":{
            "senderId":"6205975",
            "senderType":"user",
            "senderUserLevel":"member"
        },
        "chat":{
            "chatId":"823279556",
            "chatType":"group"
        },
        "message":{
            "msgId":"93d75fe100c74124b5102183df0f37ae",
            "parentId":"9a54f178eb5c4e2b84d23603e7fb5d5b",
            "sendTime":1673194941771,
            "chatId":"823279556",
            "chatType":"group",
            "contentType":"text",
            "content":{
                "text":"嚎",
                "parent":"一一世开: 现在先不要发消息"
            },
            "instructionId":0,
            "instructionName":""
        }
    }
}



{
    "version":"1.0",
    "header":{
        "eventId":"0720b23a126442929e1e0047100520de",
        "eventType":"message.receive.instruction",
        "eventTime":1673194925279
    },
    "event":{
        "sender":{
            "senderId":"3654755",//发送者ID
            "senderType":"user",
            "senderUserLevel":"owner"//权限
        },
        "chat":{
            "chatId":"823279556",//群号
            "chatType":"group"
        },
        "message":{
            "msgId":"82ff9853cd9e4f66a6fb93a1442a23bf",
            "parentId":"",
            "sendTime":1673194925181,
            "chatId":"823279556",//群号
            "chatType":"group",
            "contentType":"text",
            "content":{
                "text":"test"
            },
            "instructionId":208,
            "instructionName":"你好"
        }
    }
}

私信
{
    "version":"1.0",
    "header":{
        "eventId":"eadc680db5a64f6385a9128919f4a3d1",
        "eventType":"message.receive.normal",
        "eventTime":1673196355960
    },
    "event":{
        "sender":{
            "senderId":"3654755",
            "senderType":"user",
            "senderUserLevel":"member"
        },
        "chat":{
            "chatId":"25203250",
            "chatType":"bot"
        },
        "message":{
            "msgId":"91409ff2d56c4c62a1ff97bf2767eb4b",
            "parentId":"",
            "sendTime":1673196355953,
            "chatId":"25203250",
            "chatType":"bot",
            "contentType":"text",
            "content":{
                "text":"测试"
            },
            "instructionId":0,
            "instructionName":""
        }
    }
}

{
    "version":"1.0",
    "header":{
        "eventId":"c428ad89304341fb83ec05f23ed8fe5d",
        "eventType":"message.receive.normal",
        "eventTime":1673196717145
    },
    "event":{
        "sender":{
            "senderId":"3654755",
            "senderType":"user",
            "senderUserLevel":"member"
        },
        "chat":{
            "chatId":"25203250",
            "chatType":"bot"
        },
        "message":{
            "msgId":"0bf24bcf33bd4a4f8a5d9a83e294f044",
            "parentId":"",
            "sendTime":1673196717139,
            "chatId":"25203250",
            "chatType":"bot",
            "contentType":"text",
            "content":{
                "text":"kksk测试"
            },
            "instructionId":0,
            "instructionName":""
        }
    }
}
*/
//"content":{"formJson":{"rchiah":{"id":"rchiah","label":"IP地址","type":"input","value":"127.0.0.1"}}}

$data=json_decode($data,true);
$authority=$data['event']['sender']['senderUserLevel'];
if($authority == "member"){
$quanxian="普通成员";
}else if($authority == "owner"){
$quanxian="创建者";
}else{
$quanxian="管理员";//administrator
}
$msgtype=$data['event']['chat']['chatType'];





$sendid=$data['event']['sender']['senderId'];
$userid=$data['event']['chat']['chatId'];
if($data['event']['message']['contentType'] == "image"){
$tz=@file_get_contents("bot/Switch/Graph-turn/".$sendid.".txt");
if($tz == 1){
$msg=$data['event']['message']['content']['imageUrl'];
@file_put_contents("bot/Switch/Graph-turn/".$sendid.".txt","0");
}else{
$msg='';
}
}else{
$message=$data['event']['message']['content']['text'];
$id=$data['event']['message']['instructionId'];

if($id == 211 || $message == "菜单" || $message == "功能"){
$msg=
'| 功能名称 | 指令用法 |
| ------------- |:-------------:|
| 开发者工具箱 数据测试  | 站长工具 |
| 随机一言语录  | 随机一言 |
| 每日一句话语录 | 每日一句 |
| 疯狂星期四语录  | 疯狂星期四 |
| 图片转链接(云湖图床) | 图转 |
| MC服务器信息查询 | MC查询(基岩/java)+ip或域名+[空格]+端口 |
| 入群/退群通知(未加群通知开关) | 通知系统 |
| 多选点歌 | 点歌系统 |
| 文字作图 | 作图系统 |
| 疫情查询 | 疫情+地区(不带县字) |
| Emoji表情合成 | 表情合成+两个emoji表情 |
| 端口扫描 | 端口扫描+ip地址+[空格]+端口 |
| 联系开发者 | 联系我们 |
| 四则运算 | 计算+算式 |
| BOT运行状态 | 运行状态 |';
$contentType="markdown";
}else if($message == "站长工具"){
$contentType="markdown";
$msg=
'| 功能名称 | 指令用法 |
| ------------- |:-------------:|
| 网站Ping测速 归属地 | ping+域名 |
| 请求数据 | get+网址/post+网址+[空格]+POST参数(post功能开中) |
| 发送图片 | img+图片直链 |
| 摩斯电码 | 摩斯电码(加密/解密)+内容 |
| URL编码 | url(加密/解密)+内容 |
| base64加密 | base64(加密/解密)+内容 |
| hex加密 | hex+内容 |
| 网站状态码查询 | 状态码+域名 |
| 网站权重查询 | 权重+域名 |';
}else if($message == "作图系统"){
$msg=
'| 功能名称 | 指令用法 |
| ------------- |:-------------:|
| 诺基亚短信 | 诺基亚+文字 |
| 粉丝举牌 | 粉丝举牌+文字 |
| 小人举牌 | 举牌+文字 |';
$contentType="markdown";
}else if($message == "点歌系统"){
$msg=
'| 功能名称 | 指令用法 |
| ------------- |:-------------:|
| 网易点歌 | 点歌+歌名 |
| 网易选歌 | 选歌+序号 |
| 网易歌词 | 选词+序号 |
| 酷我点歌(支持VIP) | 酷我点歌+歌名 |
| 酷我选歌 | 酷我选歌+序号 |';
$contentType="markdown";
}else if($id == 212 || $message == "我的信息"){
if($msgtype == 'bot'){
$msg='| 用户 | 信息 |
| ------------- |:-------------:|
| 用户ID | '.$sendid.' |';
}else{
$msg='| 用户 | 信息 |
| ------------- |:-------------:|
| 群ID | '.$userid.' |
| 用户ID | '.$sendid.' |
| 权限 | '.$quanxian.' |';
}
$contentType="markdown";
}else if($id == 214 || $message == "随机一言"){
$msg=teacher_curl("https://xiaobapi.top/api/xb/api/yiyan.php");
}else if($id == 213 || $message == "疯狂星期四"){
$msg=teacher_curl("https://xiaobapi.top/api/xb/api/crazy_thursday.php");
}else if($message == "测试"){
$msg="运行正常";
}else if($id == 215 || $message == "每日一句"){
$data=teacher_curl("https://xiaobapi.top/api/xb/api/yiju.php?type=json");
$data=json_decode($data,true);
$msg='[![图片]('.$data['image'].')]('.$data['tts'].")  \n## **".$data['chinese'].'**  \n## **'.$data['english'].'**  \nTips：点击图片播放语音';
$contentType="markdown";
}else if(strstr($message,"get")){
$result = preg_match_all('/get([\s\S]*)/',$message,$v);
$msg=teacher_curl($v[1][0]);
}else if(strstr($message,"复读")){
$result = preg_match_all('/复读([\s\S]*)/',$message,$v);
$msg=$v[1][0];
}else if(strstr($message,"图转")){
@file_put_contents("bot/Switch/Graph-turn/".$sendid.".txt","1");
$msg="已开启图转链接，请发送图片！";
}else if(strstr($message,"格式化")){
$result = preg_match_all('/格式化([\s\S]*)/',$message,$v);
$msg=send(json_decode($v[1][0],true));
}else if(strstr($message,"计算")){
$result = preg_match_all('/计算([\s\S]*)/',$message,$v);
$msg=teacher_curl("https://xiaobapi.top/api/xb/api/operation.php?msg=".$v[1][0]);
}else if(strstr($message,"状态码")){
$result = preg_match_all('/状态码([\s\S]*)/',$message,$v);
$msg=teacher_curl("https://xiaobapi.top/api/xb/api/ztmcx.php?url=".$v[1][0]);
}else if(strstr($message,"权重")){
$result = preg_match_all('/权重([\s\S]*)/',$message,$v);
$msg=teacher_curl("https://xiaobapi.top/api/xb/api/quanzhong.php?url=".$v[1][0]);
}else if(strstr($message,"base64")){
$result = preg_match_all('/base64(加密|解密)([\s\S]*)/',$message,$v);
if(!$v[2][0]){
$msg="请输入内容";
}else{
if($v[1][0] == "加密"){
$r=base64_encode($v[2][0]);
$msg=$r;
}else if($v[1][0] == "解密"){
$r=base64_decode($v[2][0]);
$msg=$r;
}else{
}
}
}else if(strstr($message,"url")){
$result = preg_match_all('/url(加密|解密)([\s\S]*)/',$message,$v);
if(!$v[2][0]){
$msg="请输入内容";
}else{
if($v[1][0] == "加密"){
$r=urlencode($v[2][0]);
$msg=$r;
}else if($v[1][0] == "解密"){
$r=urldecode($v[2][0]);
$msg=$r;
}else{
}
}
}else if(strstr($message,"摩斯电码")){
$result = preg_match_all('/摩斯电码(加密|解密)([\s\S]*)/',$message,$v);
//$contentType="markdown";
if(!$v[2][0]){
/*
$msg=
'| 摩斯电码 | 加密 |
| ------------- |:-------------:|
| 请输入内容！ |  |';
*/
$msg="请输入内容";
}else{
if($v[1][0] == "加密"){
$r=teacher_curl("https://xiaobapi.top/api/xb/api/mesdm.php?type=en&msg=".$v[2][0]);
/*
$msg=
'| 摩斯电码 | 加密 |
| ------------- |:-------------:|
| 原文 | '.$v[2][0].' |
| 加密 | '.$r.' |';
*/
$msg=$r;
}else if($v[1][0] == "解密"){
$r=teacher_curl("https://xiaobapi.top/api/xb/api/mesdm.php?type=de&msg=".$v[2][0]);
/*
$msg=
'| 摩斯电码 | 解密 |
| ------------- |:-------------:|
| 原文 | '.$v[2][0].' |
| 解密 | '.$r.' |';
*/
$msg=$r;
}else{
}
}
}else if($id == 220 || strstr($message,"ping")){
if(!$id){
$result = preg_match_all('/ping([\s\S]*)/',$message,$v);
$area=$v[1][0];
}else{
$ip=$message;
}
$msg=teacher_curl("https://xiaobapi.top/api/xb/api/ping_2.php?url=".$ip);
}else if($id == 221 || strstr($message,"疫情")){
if(!$id){
$result = preg_match_all('/疫情([\s\S]*)/',$message,$v);
$area=$v[1][0];
}else{
$area=$message;
}
$msg=teacher_curl("https://xiaobapi.top/api/xb/api/chayiqing.php?msg=".$area);
}else if($id == 1 || strstr($message,"粉丝举牌")){
if(!$id){
$result = preg_match_all('/粉丝举牌([\s\S]*)/',$message,$v);
$text=$v[1][0];
}else{
$text=$message;
}
/*
$contentType="markdown";
$msg="![图片](https://xiaobapi.top/api/xb/api/fans_jupai.php?msg=".urlencode($text).")";
*/
}else if($id == 1 || strstr($message,"举牌")){
if(!$id){
$result = preg_match_all('/举牌([\s\S]*)/',$message,$v);
$text=$v[1][0];
}else{
$text=$message;
}
/*
$contentType="markdown";
$msg="![图片](https://xiaobapi.top/api/xb/api/jupai.php?msg=".urlencode($text).")";
*/
$contentType="image";
$imageUrl="https://xiaobapi.top/api/xb/api/jupai.php?msg=".urlencode($text);

}else if($id == 1 || strstr($message,"诺基亚")){
if(!$id){
$result = preg_match_all('/诺基亚([\s\S]*)/',$message,$v);
$text=$v[1][0];
}else{
$text=$message;
}
$contentType="markdown";
$msg="![图片](https://xiaobapi.top/api/xb/api/nokia.php?msg=".urlencode($text).")";
}else if($id == 222 || strstr($message,"小冰")){
if(!$id){
$result = preg_match_all('/小冰([\s\S]*)/',$message,$v);
$ai=$v[1][0];
}else{
$ai=$message;
}

$data=teacher_curl("https://xiaobapi.top/api/xb/api/xiaoai.php?type=json&msg=".strtr($ai,['小冰'=>'小爱']));
$data=json_decode($data,true);
$text=$data['data']['text'];
$url=$data['data']['audio'];
$msg="[".strtr($text,['小爱'=>'小冰'])."](".$url.")";
$contentType="markdown";
}else if(strstr($message,"BV")){
$result = preg_match_all('/BV([\s\S]*)/',$message,$v);
$msg=teacher_curl("http://xiaobapi.top/api/xb/api/bv.php?bv=BV".$v[1][0]);
}else if(strstr($message,"联系我们")){
$contentType="markdown";
$msg='| 联系开发者 | 联系方式 |
| ------------- |:-------------:|
| QQ昵称 | 一一世开 |
| QQ号 | 1044945572(大号，准备弃用) |
| QQ号 | 490593431(小号) |
| B站昵称 | 一一世开 |
| B站UID | 689343406 |
| 云湖昵称 | 一一世开_小冰科技 |
| 云湖ID | 3654755 |
| 云湖内测群ID | 823279556 |';
}else if(strstr($message,"运行状态")){
$num_out_data=file_get_contents("bot/num/".$date."_out.txt");
$num_in_data=file_get_contents("bot/num/".$date."_in.txt");
$num_all_in_data=file_get_contents("bot/num/all_in.txt");
$num_all_out_data=file_get_contents("bot/num/all_out.txt");
if(!$num_out_data){
$num_out_data='0';
}
if(!$num_in_data){
$num_in_data='0';
}
if(!$num_all_in_data){
$num_all_in_data='0';
}
if(!$num_all_out_data){
$num_all_out_data='0';
}
$contentType="markdown";
$msg='| 小冰科技BOT | 运行状态 |
| ------------- |:-------------:|
| BOT状态 | 运行正常 |
| 总共 |
| 接收消息 | '.$num_all_in_data.' 条 |
| 发送消息 | '.($num_all_out_data+1).' 条 |
| 今日 |
| 接收消息 | '.$num_in_data.' 条 |
| 发送消息 | '.($num_out_data+1).' 条 |';
}else if($id == 217 || strstr($message,"端口扫描")){
if(!$id){
$result = preg_match_all('/端口扫描([\s\S]*) ([\s\S]*)/',$message,$v);
$ip=$v[1][0];
$port=$v[2][0];
}else{
$ip=$data['event']['message']['content']['formJson']['exhvnd']['value'];
$port=$data['event']['message']['content']['formJson']['lwswhz']['value'];
}
$msg=teacher_curl("https://xiaobapi.top/api/xb/api/dksm.php?type=text&ip=".$ip.'&port='.$port);
}else if($id == 217 || strstr($message,"MC查询")){
if(!$id){
$result = preg_match_all('/MC查询基岩([\s\S]*) ([\s\S]*)/',$message,$v);
$ip=$v[1][0];
$port=$v[2][0];
$t="Bedrock";
if(!$ip){
$result = preg_match_all('/MC查询java([\s\S]*) ([\s\S]*)/',$message,$v);
$ip=$v[1][0];
$port=$v[2][0];
$t="Java";
}
}else{
$ip=$data['event']['message']['content']['formJson']['exhvnd']['value'];
$port=$data['event']['message']['content']['formJson']['lwswhz']['value'];
}
$data=json_decode(teacher_curl("https://xiaobapi.top/api/xb/api/view_minecraft_server_query.php?type=".$t."&host=".$ip.'&port='.$port),true);
if($data['code'] == 1){
$msg="| 项目 | 信息 |
| ------------- |:-------------:|
| 状态 | 获取成功 |
| IP/域名 | ".$data['Host']." |
| 端口 | ".$data['Port']." |
| 服务器类型 | ".$t." |
| 服务器延迟 | ".$data['data']['PostPone']." s |
| MC版本 | ".$data['data']['Version']." |
| 在线玩家 | ".$data['data']['Players']." |
| 最大玩家数 | ".$data['data']['MaxPlayers']." |
| 服务器简介 | ".$data['data']['HostName']." |
| 地图名字 | ".$data['data']['Map']." |
| Mods名字 | ".$data['data']['GameMode']." |
| 游戏名字 | ".$data['data']['GameName']." |";
}else if($data['code'] == -1){
$msg="| 项目 | 信息 |
| ------------- |:-------------:|
| 状态 | 获取失败，请检查你的端口是否正确，服务器是否开启 |";
}
$contentType="markdown";
}else if($id == 1 || strstr($message,"酷我点歌")){
if(!$id){
$result = preg_match_all('/酷我点歌([\s\S]*)/',$message,$v);
$song=$v[1][0];
}else{
$song=$message;
}
@file_put_contents("bot/function_data/Request_song/".$sendid.".txt",$song);
$data=teacher_curl("https://xiaobapi.top/api/xb/api/kuwo_vip.php?type=json&msg=".$song);
$data=json_decode($data,true);
$msg="| 序号 | 歌名 | 歌手 |
| ------------- |:-------------:| ------------- |
";
for($i=0;$i < count($data['data']['content'][1]['musicpage']);$i++){
$artist=$data['data']['content'][1]['musicpage'][$i]['album'];
$name=$data['data']['content'][1]['musicpage'][$i]['name'];
$msg=$msg."| ".($i+1)."： | ".$name." | ".$artist." |
";
}
$msg=$msg."| 搜索到".count($data['data']['content'][1]['musicpage'])."首歌曲 | 选择歌曲发送指令→ | 酷我选歌+序号 |
| 当前为酷我点歌 | 指令示例→ | 酷我选歌1 |";
$contentType="markdown";
}else if(strstr($message,"酷我选歌")){
$result = preg_match_all('/酷我选歌([0-9]+)/',$message,$v);
$dg=@file_get_contents("bot/function_data/Request_song/".$sendid.".txt");
if(!$dg){
$msg="你还没有点歌";
}else{
$data=teacher_curl("https://xiaobapi.top/api/xb/api/kuwo_vip.php?msg=".$dg."&type=json");
$data=json_decode($data,true);
$artist=$data['data']['content'][1]['musicpage'][($v[1][0]-1)]['album'];
$name=$data['data']['content'][1]['musicpage'][($v[1][0]-1)]['name'];
$pic=$data['data']['content'][1]['musicpage'][($v[1][0]-1)]['albumPic'];
$id=$data['data']['content'][1]['musicpage'][($v[1][0]-1)]['id'];
$data=teacher_curl("https://xiaobapi.top/api/xb/api/kuwo_vip.php?msg=".$dg."&type=json&n=".$v[1][0]);
$data=json_decode($data,true);
$music=$data['data']['audioUrl'];
$msg="# **[![歌曲图片](".$pic.")".$name."--".$artist."](".$music.")**";
$contentType="markdown";
}
}else if($id == 219 || strstr($message,"点歌")){
if(!$id){
$result = preg_match_all('/点歌([\s\S]*)/',$message,$v);
$song=$v[1][0];
}else{
$song=$message;
}
@file_put_contents("bot/function_data/Request_song/".$sendid.".txt",$song);
$data=teacher_curl("https://xiaobapi.top/api/xb/api/netease.php?type=json&msg=".$song);
$data=json_decode($data,true);
$msg="| 序号 | 歌名 | 歌手 |
| ------------- |:-------------:| ------------- |
";
for($i=0;$i < count($data['data']['data']);$i++){
$ge=$data['data']['data'][$i]['artist'];
$artist="xbkjapi";
for( $b = 0 ; $b < count($ge); $b ++ ){
$artist=$artist."-".$ge[$b];
}
$artist=strtr($artist,['xbkjapi-'=>'']);
$name=$data['data']['data'][$i]['name'];
$msg=$msg."| ".($i+1)."： | ".$name." | ".$artist." |
";

}
$msg=$msg."| ".$data['data']['result']." | 指令↓↓选择歌曲发送：选歌+序号 | 指令↓↓获取歌词发送：选词+序号 |
| 当前为网易点歌 | 示例：选歌1 | 示例：选词1 |";
$contentType="markdown";
}else if(strstr($message,"选歌")){
$result = preg_match_all('/选歌([0-9]+)/',$message,$v);
$dg=@file_get_contents("bot/function_data/Request_song/".$sendid.".txt");
if(!$dg){
$msg="你还没有点歌";
}else{
$data=teacher_curl("https://xiaobapi.top/api/xb/api/netease.php?msg=".$dg."&type=json&n=".$v[1][0]);
$data=json_decode($data,true);
$pic=$data['data']['pic_url'];
$ga=$data['data']['name'];
$gb=$data['data']['artist'];
$music=$data['data']['music_url'];
$artist="";
for( $b = 0 ; $b < count($gb); $b ++ ){
$artist=$artist."-".$gb[$b];
}
$msg="# **[![歌曲图片](".$pic.")".$ga.$artist."](".$music.")**";
$contentType="markdown";
}
}else if(strstr($message,"选词")){
$result = preg_match_all('/选词([0-9]+)/',$message,$v);
$dg=@file_get_contents("bot/function_data/Request_song/".$sendid.".txt");
if(!$dg){
$msg="你还没有点歌";
}else{
$msg=json_decode(teacher_curl("https://xiaobapi.top/api/xb/api/netease.php?msg=".$dg."&type=json&n=".$v[1][0]),true)['data']['lyric']['lrc']['lyric'];
}
}else if(strstr($message,"img")){
$result = preg_match_all('/img([\s\S]*)/',$message,$v);
/*
$contentType="markdown";//"image";
$msg='![Name]('.$v[1][0].')';
*/
$contentType="image";
$imageUrl='https://chat-storage1.jwznb.com/879b8951ebf0e3bb4170e9086752b2a5.jpg?sign=0aa6e6fde6fd6411540180576ec7323b&t=63d211ba';
}else if(strstr($message,"表情合成")){
$result = preg_match_all('/表情合成([\s\S]*)/',$message,$v);
$data=teacher_curl('https://xiaobapi.top/api/xb/api/emoji_synthesis.php?emoji='.$v[1][0]);
$data=json_decode($data,true);
$contentType="markdown";
if($data['code'] ==  '1'){
$url=$data['url']['url'];
$msg='![Name]('.$url.')';
}else{
$msg='这两个表情可能不支持合成';
}
}else if(strstr($message,"支付宝到账")){
$result = preg_match_all('/支付宝到账([\s\S]*)/',$message,$v);
$contentType="markdown";
$msg='[点我听语音](https://xiaobapi.top/api/xb/api/alipay_tts.php?msg='.$v[1][0].')';
}else{
$msg='';
}

}

$eventType=$data['header']['eventType'];
if($eventType == 'message.receive.normal'){//普通消息事件
//
}else if($eventType == 'message.receive.instruction'){//指令消息事件
//
}else if($eventType == 'bot.followed'){//关注机器人事件
/*
{
    "version":"1.0",
    "header":{
        "eventId":"fc6795f24d2c42ab9f8dc263891efc57",
        "eventType":"bot.followed",
        "eventTime":1673432259790
    },
    "event":{
        "time":1673432259778,
        "chatId":"25203250",
        "chatType":"bot",
        "userId":"3161064",
        "nickname":"JV",
        "avatarUrl":"https://chat-img.jwznb.com/10b9e1b1e5262f2ee6676668d1647d9e.jpg"
    }
}
*/
send_msg(array(
    'userid'=>$data['event']['userId'],
    'msgtype'=>"user",
    'contentType'=>"text",
    'imageUrl'=>$imageUrl,
    'msg'=>"感谢".$data['event']['nickname']."使用小冰科技机器人，发送 菜单 查看更多功能开始使用吧~",
    'headers'=>"application/json",
));

$contentType="markdown";
$pic=$data['event']['avatarUrl'];
$msg="# [![头像](".$pic."#150x150)](".$pic.") **@".$data['event']['nickname']."(".$data['event']['userId'].") 关注了机器人**";

}else if($eventType == 'bot.unfollowed'){//取消关注机器人事件
$contentType="markdown";
$pic=$data['event']['avatarUrl'];
$msg="# [![头像](".$pic."#150x150)](".$pic.") **@".$data['event']['nickname']."(".$data['event']['userId'].") 取关了机器人**";

}else if($eventType == 'group.join'){//加入群事件
/*
{
    "version":"1.0",
    "header":{
        "eventId":"9d5009cd70024eebbb218bcf01948e93",
        "eventType":"group.leave",
        "eventTime":1673371664996
    },
    "event":{
        "time":1673371664832,
        "chatId":"823279556",
        "chatType":"group",
        "userId":"3161064",
        "nickname":"JV",
        "avatarUrl":"https://chat-img.jwznb.com/10b9e1b1e5262f2ee6676668d1647d9e.jpg"
    }
}
*/
$contentType="markdown";
$pic=$data['event']['avatarUrl'];
$msg="# [![头像](".$pic."#150x150)](".$pic.") **欢迎@".$data['event']['nickname']."(".$data['event']['userId'].") 加入了本群！**";

}else if($eventType == 'group.leave'){//退出群事件
$contentType="markdown";
$pic=$data['event']['avatarUrl'];
$msg="# [![头像](".$pic."#150x150)](".$pic.") **@".$data['event']['nickname']."(".$data['event']['userId'].") 退出了本群！**";
}


if($msgtype == "user"){
send_msg(array(
    'userid'=>"823279556",
    'msgtype'=>"group",
    'contentType'=>"text",
    'imageUrl'=>$imageUrl,
    'msg'=>$message,
    'headers'=>$headers,
));
}

if(!$contentType){
$contentType="text";
}
if($contentType == "markdown"){
$headers=="markdown";
}else{
$headers=="application/json";
}
//{"version":"1.0","header":{"eventId":"7792689bd028466f88de1f59572a3efa","eventType":"group.join","eventTime":1673372776792},"event":{"time":1673372776703,"chatId":"823279556","chatType":"group","userId":"3161064","nickname":"JV","avatarUrl":"https://chat-img.jwznb.com/10b9e1b1e5262f2ee6676668d1647d9e.jpg"}}
if($eventType == 'group.leave' || $eventType == 'group.join'){
$userid=$data['event']['chatId'];
$msgtype='group';
}else if($eventType == 'bot.followed' || $eventType == 'bot.unfollowed'){
$userid="823279556";
$msgtype='group';
}else{
$msgtype=strtr($msgtype,['bot'=>'user']);
if($msgtype == "user"){
$userid=$sendid;
}
}


if($msgtype == "user"){
$test_type=$data['event']['message']['contentType'];
if($test_type == "text"){
$test_contentType="markdown";
$test_headers=="markdown";
$test_msg="| BOT事件 | 有人私信 |
| ------------- |:-------------:|
| 消息类型 | Text 文字 |
| 消息时间 | ".date("Y-m-d H:i:s")." |
| 用户ID | ".$userid." |
| 发送消息 | ".$message." |";
send_msg(array(
    'userid'=>"823279556",
    'msgtype'=>"group",
    'contentType'=>$test_contentType,
    'imageUrl'=>$imageUrl,
    'msg'=>$test_msg,
    'headers'=>$test_headers,
));

if(!$msg){
$data=teacher_curl("https://xiaobapi.top/api/xb/api/xiaoai.php?type=json&msg=".strtr($message,['小冰'=>'小爱']));
$data=json_decode($data,true);
$text=$data['data']['text'];
$url=$data['data']['audio'];
$msg="[".strtr($text,['小爱'=>'小冰'])."](".$url.")";
$contentType="markdown";
}else{
}

}else{
$test_contentType="markdown";
$test_headers=="markdown";
$test_pic=$data['event']['message']['content']['imageUrl'];
$test_msg="| BOT事件 | 有人私信 |
| ------------- |:-------------:|
| 消息类型 | Image 图片 |
| 消息时间 | ".date("Y-m-d H:i:s")." |
| 用户ID | ".$userid." |
| 发送图片 | 如下图片 |

# [![图片](".$test_pic.")](".$test_pic.")";
send_msg(array(
    'userid'=>"823279556",
    'msgtype'=>"group",
    'contentType'=>$test_contentType,
    'imageUrl'=>$imageUrl,
    'msg'=>$test_msg,
    'headers'=>$test_headers,
));

}
}


if(!$msg){
exit;
}

send_msg(array(
    'userid'=>$userid,
    'msgtype'=>$msgtype,
    'contentType'=>$contentType,
    'imageUrl'=>$imageUrl,
    'msg'=>$msg,
    'headers'=>$headers,
));
/*
file_put_contents("yhbot.txt",json_encode(array(
    'userid'=>$userid,
    'msgtype'=>$msgtype,
    'contentType'=>$contentType,
    'imageUrl'=>$imageUrl,
    'msg'=>$msg,
    'headers'=>$headers,
)));
*/
function send_msg($array=array()){
$date=date("Y-m-d");
$num_out_data=file_get_contents("bot/num/".$date."_out.txt");
if(!$num_out_data){
$num_out_data='0';
}
file_put_contents("bot/num/".$date."_out.txt",($num_out_data+1));

$num_all_out_data=file_get_contents("bot/num/all_out.txt");
if(!$num_all_out_data){
$num_all_out_data='0';
}
file_put_contents("bot/num/all_out.txt",($num_all_out_data+1));

$userid=$array['userid'];
$msgtype=$array['msgtype'];
$contentType=$array['contentType'];
$imageUrl=$array['imageUrl'];
$msg=$array['msg'];
$headers=$array['headers'];

$hh='
';

$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://chat-go.jwzhd.com/open-apis/v1/bot/send?token=你的机器人token',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{
    "recvId": "'.$userid.'",
    "recvType": "'.$msgtype.'",
    "contentType": "'.$contentType.'",
    "content": {
        "text": "'.strtr($msg,[$hh=>'\n']).'",
        "imageUrl": "'.$imageUrl.'"
    }
}',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: '.$headers
  ),
));
$response = curl_exec($curl);
curl_close($curl);
//return $response;
}



